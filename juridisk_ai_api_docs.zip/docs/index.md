# Juridisk AI – Dokumentation

Detta system analyserar juridiska texter enligt svensk rätt och föreslår strategier, risker och skadestånd.
